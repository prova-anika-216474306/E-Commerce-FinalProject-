package backendtest;

import static org.junit.Assert.*;

import org.junit.Test;

public class AdminDaoTest {

	@Test
	public void testGetAllStore() {
		
	}

	@Test
	public void testGetAllManager() {
		fail("Not yet implemented");
	}

	@Test 
	public void testGetAllCustomers() {
		fail("Not yet implemented");
	}

}
